import {Component} from '@angular/core';

@Component({
    selector:'app-main',
    template:'<H1> Hello World from </H1    >'
})

export class Appcomponent{
    name='Rajat';
}